package day06_a_arithmetic_operators;

public class CastingExample {

    public static void main(String[] args) {
        short numOne = 40;
        float numTwo = numOne;
     char
         letter = 'A';
     int letter2 = letter;
        System.out.println(letter2);

float num2 =100.5f;
        short num4 =(short) num2;

        System.out.println(num4);



    }
}
