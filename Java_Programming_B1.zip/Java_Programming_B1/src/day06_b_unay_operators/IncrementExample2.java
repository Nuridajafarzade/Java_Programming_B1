package day06_b_unay_operators;

public class IncrementExample2 {
    public static void main(String[] args) {

       int age =20;
        System.out.println(age--); //20 --- age =age - 1-->19



        System.out.println(age); //19

        System.out.println(++age); //age =age + 1 --->20

        System.out.println(--age); //19
        --age; //age =age -1 ---> 18

        System.out.println(--age);// 17










    }
}
