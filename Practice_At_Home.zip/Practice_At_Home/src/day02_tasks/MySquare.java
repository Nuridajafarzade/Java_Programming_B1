package day02_tasks;

public class MySquare {

    public static void main(String[] asge){
    System.out.println("----");
    System.out.println("|  |");
    System.out.println("----");


}


}